from pyMarkupL.core.compiler import Compiler
from pyMarkupL.core.exceptions import ProjectInitError

class Command:

    def __init__(self, argv: list, settings=None):
        self.argv = argv
        self.settings = settings
        self.analyze_command()

    def is_equals(self, arg1, *args):

        for arg in args:
            if arg1.lower() == arg.lower():
                return True

        return False

    def cwd_file_exist(self, path) -> bool:
        import os

        return os.path.exists(path)


    def analyze_command(self):

        if len(self.argv) == 1:
            self.help_()

            return

        if self.is_equals(self.argv[1], 'start', 'init', 'startproject'):
            self.init()

        if self.is_equals(self.argv[1], 'help', '-h', 'ajuda', '--help'):
            self.help_()

        if not self.settings:
            self.help_()

            return

        elif self.is_equals(self.argv[1], 'compile', 'compilar', 'cpl'):
            self.compile()

        elif self.is_equals(self.argv[1], 'run', 'rodar', 'runserver'):
            self.run()

        else:
            self.help_()

    def generate_files(self, files):
        pass
    
    def init(self):
        import os
        import pyMarkupL
        import shutil
        import distutils.dir_util

        pymarkupL = os.path.dirname(os.path.abspath(pyMarkupL.__file__))
        
        startstructure_path = os.path.join(pymarkupL, 'startstructure')
        
        init_files = os.listdir(startstructure_path)
        print(init_files)

        for init_file in init_files:
            if self.cwd_file_exist(os.path.join(os.getcwd(), init_file)):
                # TODO: give you the option to rewrite the file or directory

                print(f'{init_file} already exists in your project')
                continue
            init_file_path = os.path.join(startstructure_path, init_file)
            
            try:
                if os.path.isdir(init_file_path):

                    src_dir = os.path.join(os.getcwd(), init_file)
                    os.mkdir(src_dir)
                    distutils.dir_util.copy_tree(init_file_path, src_dir)

                    continue

            except Exception as error:
                raise ProjectInitError('Your project could not be initialized! ' + str(error))

            print(init_file_path)

            try:
                shutil.copy(init_file_path, os.getcwd())
            except Exception as error:
                raise ProjectInitError('Your project could not be initialized! ' + str(error))


    def help_(self):
        # TODO: implement the help interface
        ...

    def compile(self):
        compiler = Compiler(self.settings.MAIN_ELEMENT, self.settings)
        compiler.generate()

    def run(self):
        if '-e' in self.argv:
            # TODO: Run the server for a specific element
            return

        compiler = Compiler(self.settings.MAIN_ELEMENT, self.settings, debug=True)
        compiler.generate()

        # TODO: Run the server
